package com.dsc.shinny;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = new Intent(this,MainActivity.class);    //go to next activity

        new Handler().postDelayed(new Runnable() {  //wait some time
            @Override
            public void run() {
                startActivity(intent);
                finish();
            }
        },1200);


    }

    public void getStarted(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}
