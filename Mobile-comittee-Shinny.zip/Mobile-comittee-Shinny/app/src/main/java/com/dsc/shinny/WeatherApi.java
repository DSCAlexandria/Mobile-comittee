package com.dsc.shinny;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface WeatherApi {
    @GET("v1/e4ef89d7")
    Call<ArrayList<Weather>> getForecast();
}
